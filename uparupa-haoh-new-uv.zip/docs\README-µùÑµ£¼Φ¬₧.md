# ウパルパ鯖 独自装備リソースパック v0.1

対象は Java Edition 1.21.11。PNG、Minecraft 1.21.11のアイテムモデル定義、MythicMobs用の別サンプル設定を同梱しています。

## 導入

1. ZIPを解凍せず、`uparupa-haoh-1.21.11.zip`をクライアントの`.minecraft/resourcepacks`へ置く。
2. Minecraftの「設定 → リソースパック」で有効化する。
3. サーバー側のMythicMobsに、`MythicMobs-items-example.yml`を**原本をバックアップした上で新規ファイルとして**配置する。
4. `/mm reload`後、`/mm items get HaohApocalypseGreatsword_RP 1`で自分（rei122209）だけにテスト付与する。

## 重要な前提

この版は`CustomModelData`を使うため、アイテムの見た目はインベントリ・手持ちで切り替わります。1.21.11では`minecraft:custom_model_data`の数値を`range_dispatch`で分岐しています。

防具を装備したときの全身3D見た目は、バニラの防具レイヤーだけでは個別アイテムごとに安全に切り替えられません。別の防具表示ブリッジ、またはWeaponMaster側がitem model/equipment modelを付与する実装が必要です。今回のPNGはアイコンとレイヤー素材の第1版です。

WeaponMasterは公式仕様上、既存の武器・防具・ゲームプレイを追加するプラグインで、任意のMythicMobsアイテムを自動的にWeaponMaster製アイテムへ変換する設定方式は確認できません。そのため、スキル処理はMythicMobs、表示はこのリソースパック、必要なら後で小さなPaper連携プラグインという分担にします。

## 直接テストするコマンド

```text
/give rei122209 minecraft:netherite_sword[minecraft:custom_model_data={floats:[1001]}] 1
/give rei122209 minecraft:netherite_helmet[minecraft:custom_model_data={floats:[2001]}] 1
```

サーバー上でアイテムが切り替わらない場合は、MythicMobsのバージョンと`/data get entity rei122209 SelectedItem`の結果を確認してください。リソースパックURLやサーバー設定へ反映する前にテストワールドで確認します。
